<?php 
require_once('config.php');
redirect('customer');
?>
 